<?php

// ============================================================
// superadmin.admin.block.php
// ============================================================
// Block / unblock / suspend a reading-hall admin.
//
// When blocked/suspended:
//   • Admin's JWT is rejected by AuthMiddleware (live DB check)
//   • Admin cannot login until unblocked
//   • Existing student data is preserved (soft, reversible)
//
// Required permission: manage_admins (root bypasses)
//
// Required body:
//   { admin_id: 5, action: "block" }
//   { admin_id: 5, action: "unblock" }
//   { admin_id: 5, action: "suspend" }
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminAdminController',
    'superAdminValidator',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

Request::InputRequirements(['admin_id', 'action'], $input);

SuperAdminValidator::validateAdminAction($input);

(new SuperAdminAdminController())->changeStatus($input);
