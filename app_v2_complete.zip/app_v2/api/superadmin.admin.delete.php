<?php

// ============================================================
// superadmin.admin.delete.php
// ============================================================
// Soft-delete a reading-hall admin account.
//
// What soft-delete does:
//   • Sets admins.deleted_at = NOW()
//   • Sets admins.status = 'blocked'
//   • Admin cannot login, all their APIs return 401
//   • All their data (branches/halls/students/fees) is
//     preserved in DB for audit trail — nothing is erased
//
// This is IRREVERSIBLE via the API — to restore, a DB admin
// must manually set deleted_at = NULL.
//
// Required permission: manage_admins (root bypasses)
//
// Required body: { admin_id: 5 }
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminAdminController',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

if (empty($input['admin_id'])) {
    Response::error('admin_id is required', 400);
}

// Extra confirmation field prevents accidental deletes
if (empty($input['confirm']) || $input['confirm'] !== 'DELETE') {
    Response::error('Send { confirm: "DELETE" } to confirm this action', 400);
}

(new SuperAdminAdminController())->delete($input);
