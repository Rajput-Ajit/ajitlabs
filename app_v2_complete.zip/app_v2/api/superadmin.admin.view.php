<?php

// ============================================================
// superadmin.admin.view.php
// ============================================================
// Full detail of a single reading-hall admin.
//
// Returns:
//   profile          → all admin fields (password_hash excluded)
//   plan info        → current plan name, limits
//   branches         → all branches with city + status
//   recent_students  → last 5 registered students
//   subscription_history → last 10 subscription records
//
// Required body: { admin_id: 5 }
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminAdminController',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

if (empty($input['admin_id'])) {
    Response::error('admin_id is required', 400);
}

(new SuperAdminAdminController())->view($input);
