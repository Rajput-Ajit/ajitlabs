<?php

// ============================================================
// superadmin.admins.list.php
// ============================================================
// Paginated list of ALL reading-hall admins on the platform.
// Each row includes: profile, plan, branch/hall/student counts,
// total revenue, subscription status, pending payment flag.
//
// Optional filters (JSON body):
//   search       → name / email / contact
//   status       → active | blocked | suspended
//   plan_id      → filter by plan
//   is_read_only → 1 = expired subscription admins only
//   limit        → default 15
//   offset       → default 0
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminAdminController',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

(new SuperAdminAdminController())->list($input);
