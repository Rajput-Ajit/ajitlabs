<?php

// ============================================================
// superadmin.dashboard.php
// ============================================================
// Platform-wide KPI dashboard for super admin.
//
// Returns:
//   stats   → total/active admins, students, halls, branches,
//             pending approvals, platform revenue, new admins (30d)
//   charts  → admin growth (6 months), plan distribution
//   pending_subscriptions → latest 5 pending payment approvals
//
// No filters needed — always returns full platform view.
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminDashboardController',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

(new SuperAdminDashboardController())->data();
