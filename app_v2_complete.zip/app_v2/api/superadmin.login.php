<?php

// ============================================================
// superadmin.login.php
// ============================================================
// Super admin login — issues JWT with type = 'super_admin'.
// SuperAuthMiddleware on all protected super admin APIs
// verifies this token against the super_admins table.
//
// Request body: { email, password }
// ============================================================

require_once '../config/bootstrap.php';

// Strict rate limit — brute force protection
Middleware::run([
    ['RateLimitMiddleware', 10, 60]
]);

App::useMany([
    'superAdminAuthController',
    'superAdminValidator',
]);

$input = Request::json();

if (!Request::validate(['email', 'password'], $input)) {
    Response::error('Email and password are required', 400);
}

SuperAdminValidator::validateLogin($input);

(new SuperAdminAuthController())->login($input);
