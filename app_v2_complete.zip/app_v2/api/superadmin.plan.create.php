<?php

// ============================================================
// superadmin.plan.create.php
// ============================================================
// Create a new subscription plan.
//
// Slug is auto-generated from name if not provided.
// Slug cannot be changed after creation (used as stable key
// in application logic and admin portal URLs).
//
// Required permission: manage_plans (root bypasses)
//
// Required fields:
//   name, price_monthly, max_branches, max_halls, max_students
//
// Optional fields:
//   slug (auto from name if omitted), price_yearly,
//   max_sub_admins (default 0),
//   has_analytics, has_sms_alerts, has_fee_management,
//   has_shift_timings, has_api_access (all default 0/false)
//   is_active (default 1), display_order (default 99)
//
// Example body:
// {
//   "name": "Pro Plus",
//   "price_monthly": 3999,
//   "max_branches": 10,
//   "max_halls": 0,
//   "max_students": 1000,
//   "max_sub_admins": 10,
//   "has_analytics": 1,
//   "has_sms_alerts": 1,
//   "has_fee_management": 1,
//   "has_shift_timings": 1,
//   "display_order": 4
// }
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminPlanController',
    'superAdminValidator',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

Request::InputRequirements(['name', 'price_monthly', 'max_branches', 'max_halls', 'max_students'], $input);

SuperAdminValidator::validatePlan($input);

(new SuperAdminPlanController())->create($input);
