<?php

// ============================================================
// superadmin.plan.update.php
// ============================================================
// Update an existing subscription plan.
//
// NOTE: Slug is NOT editable after creation.
// All other fields can be changed at any time.
//
// Changing max_branches / max_halls / max_students does NOT
// retroactively affect existing admins — it only applies
// from their NEXT subscription renewal.
// (Enforcement is done in admin-side services at write time.)
//
// Deactivating a plan (is_active: 0) means:
//   • New admins cannot subscribe to it
//   • Existing subscribers keep their plan until it expires
//
// Required permission: manage_plans (root bypasses)
//
// Required body: { plan_id: 2, ...fields_to_update }
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminPlanController',
    'superAdminValidator',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

if (empty($input['plan_id'])) {
    Response::error('plan_id is required', 400);
}

SuperAdminValidator::validatePlan($input);

(new SuperAdminPlanController())->update($input);
