<?php

// ============================================================
// superadmin.plans.list.php
// ============================================================
// List all subscription plans with active subscriber count.
//
// Returns all plans including inactive ones (is_active=0)
// so super admin can see and manage the full catalogue.
//
// No filters — always returns full list ordered by display_order.
//
// Response per plan:
//   id, name, slug, price_monthly, price_yearly,
//   max_branches, max_halls, max_students, max_sub_admins,
//   feature flags (has_analytics etc.),
//   is_active, display_order, active_subscribers (count)
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminPlanController',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

(new SuperAdminPlanController())->list();
