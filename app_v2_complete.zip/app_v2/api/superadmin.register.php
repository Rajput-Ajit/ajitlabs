<?php

// ============================================================
// superadmin.register.php
// ============================================================
// ONE-TIME ENDPOINT — creates the root super admin.
//
// Rules:
//   • Only works when zero super admins exist in DB.
//   • Requires SUPER_ADMIN_SETUP_KEY from .env to prevent
//     random people from claiming the root account.
//   • Once root is created, this endpoint returns 403 forever.
//   • After this, use superadmin.sub.create.php to add more
//     super admins with limited permissions.
//
// Request body:
//   { name, email, password, setup_key }
// ============================================================

require_once '../config/bootstrap.php';

// Tight rate limit — brute force protection on setup key
Middleware::run([
    ['RateLimitMiddleware', 5, 60]
]);

App::useMany([
    'superAdminAuthController',
    'superAdminValidator',
]);

$input = Request::json();

Request::InputRequirements(['name', 'email', 'password', 'setup_key'], $input);

SuperAdminValidator::validateRegister($input);

(new SuperAdminAuthController())->register($input);
