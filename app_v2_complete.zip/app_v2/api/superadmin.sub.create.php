<?php

// ============================================================
// superadmin.sub.create.php
// ============================================================
// Create a sub super admin — a team member who can help
// manage the platform on behalf of the root super admin.
//
// Sub super admins have ONLY the permissions explicitly granted.
// Root super admin (created_by = NULL) has ALL permissions.
//
// Available permission codes (from super_admin_permissions table):
//   manage_admins     — block/unblock/delete reading-hall admins
//   manage_plans      — create/edit subscription plans
//   approve_payments  — approve admin subscription payments
//   view_reports      — access platform reports
//   manage_subs       — create/edit/block sub super admins
//
// Only root or super admin with 'manage_subs' can create.
//
// Required body:
//   { name, email, password, permission_ids: [1,2,3] }
//
// permission_ids: array of IDs from super_admin_permissions table
// Send empty array [] to create with no permissions (view only).
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminSubController',
    'superAdminValidator',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

Request::InputRequirements(['name', 'email', 'password'], $input);

SuperAdminValidator::validateSubCreate($input);

(new SuperAdminSubController())->create($input);
