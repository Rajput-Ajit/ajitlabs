<?php

// ============================================================
// superadmin.sub.list.php
// ============================================================
// List all sub super admins created by this super admin.
//
// Also returns the full permissions catalogue so the frontend
// can render a checkbox list for the permissions editor.
//
// Response:
//   data      → array of sub super admins with their permissions
//   catalogue → array of all available permission codes + descriptions
//
// Optional body: { limit, offset }
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminSubController',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

(new SuperAdminSubController())->list($input);
