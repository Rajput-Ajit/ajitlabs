<?php

// ============================================================
// superadmin.sub.update.php
// ============================================================
// Update the permissions of an existing sub super admin.
//
// This does a FULL SYNC — sends the complete desired set of
// permission IDs. Any permissions not in the array are removed.
// Send an empty array [] to revoke all permissions.
//
// Only root or super admin with 'manage_subs' can call this.
// A sub super admin cannot update their own permissions.
//
// Required body:
//   {
//     "sub_admin_id": 3,
//     "permissions": [1, 3, 4]
//   }
//
// Permission IDs come from the super_admin_permissions table.
// Use superadmin.sub.list.php to get the full catalogue.
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminSubController',
    'superAdminValidator',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

Request::InputRequirements(['sub_admin_id', 'permissions'], $input);

SuperAdminValidator::validateSubUpdate($input);

(new SuperAdminSubController())->updatePermissions($input);
