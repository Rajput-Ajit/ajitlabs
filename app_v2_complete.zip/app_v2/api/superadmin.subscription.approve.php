<?php

// ============================================================
// superadmin.subscription.approve.php
// ============================================================
// Manually approve a pending admin subscription payment.
//
// Flow:
//   1. Admin pays offline (cash / UPI / bank transfer)
//   2. Admin sends payment reference to super admin
//   3. Super admin verifies payment received
//   4. Super admin calls this API → plan activates immediately
//
// What happens on approve:
//   • admin_subscriptions.status  → 'active'
//   • admin_subscriptions.approved_by → super_admin.id
//   • All other active subscriptions for that admin → 'expired'
//   • admins.plan_id              → new plan id
//   • admins.plan_expires_at      → subscription end_date
//   • admins.is_read_only         → 0 (write access restored)
//   • admins.status               → 'active' (unblocks if was expired)
// All done in a single DB transaction.
//
// Required permission: approve_payments (root bypasses)
//
// Request body:
//   { subscription_id: 12 }
//
// To reject instead: send to superadmin.subscription.reject.php
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminSubscriptionController',
    'superAdminValidator',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

Request::InputRequirements(['subscription_id'], $input);

SuperAdminValidator::validateApprove($input);

(new SuperAdminSubscriptionController())->approve($input);
