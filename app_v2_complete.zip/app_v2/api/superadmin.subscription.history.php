<?php

// ============================================================
// superadmin.subscription.history.php
// ============================================================
// All subscription records across all admins on the platform.
//
// Optional filters (JSON body):
//   status    → pending | active | expired | cancelled | refunded
//   admin_id  → filter one specific admin
//   plan_id   → filter by plan
//   search    → admin name / email
//   limit     → default 15
//   offset    → default 0
//
// Typical use cases:
//   • Default (no filter) → show all pending first (for approval queue)
//   • status=pending      → approval queue
//   • status=active       → currently active subscriptions
//   • admin_id=5          → history for one admin
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminSubscriptionController',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

(new SuperAdminSubscriptionController())->list($input);
