<?php

// ============================================================
// superadmin.subscription.reject.php
// ============================================================
// Reject a pending admin subscription.
// Admin stays on their current plan (or free/read-only).
//
// Required permission: approve_payments
//
// Request body:
//   { subscription_id: 12, note: "Payment not received" }
// ============================================================

require_once '../config/bootstrap.php';

App::useMany([
    'superAuthMiddleware',
    'superAdminSubscriptionController',
]);

Middleware::run([
    SuperAuthMiddleware::class,
]);

$input = Request::json();

if (empty($input['subscription_id'])) {
    Response::error('subscription_id is required', 400);
}

(new SuperAdminSubscriptionController())->reject($input);
