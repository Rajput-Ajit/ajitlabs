<?php

class SuperAdminAdminController
{
    private $service;

    public function __construct()
    {
        App::use('superAdminAdminService');
        $this->service = new SuperAdminAdminService();
    }

    public function list(array $data): void
    {
        Response::success($this->service->list($data));
    }

    public function view(array $data): void
    {
        $adminId = (int)($data['admin_id'] ?? 0);
        if (!$adminId) Response::error('admin_id is required', 400);
        Response::success($this->service->view($adminId));
    }

    public function changeStatus(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        Response::success($this->service->changeStatus($data, $superAdmin));
    }

    public function delete(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        $adminId    = (int)($data['admin_id'] ?? 0);
        if (!$adminId) Response::error('admin_id is required', 400);
        Response::success($this->service->delete($adminId, $superAdmin));
    }
}
