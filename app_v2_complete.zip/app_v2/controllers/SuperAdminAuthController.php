<?php
// SuperAdminAuthController.php

class SuperAdminAuthController
{
    private $service;

    public function __construct()
    {
        App::use('superAdminAuthService');
        $this->service = new SuperAdminAuthService();
    }

    public function login(array $data): void
    {
        Response::success($this->service->login($data));
    }

    public function register(array $data): void
    {
        Response::success($this->service->register($data));
    }
}
