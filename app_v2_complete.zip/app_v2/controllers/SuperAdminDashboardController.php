<?php

class SuperAdminDashboardController
{
    private $service;

    public function __construct()
    {
        App::use('superAdminDashboardService');
        $this->service = new SuperAdminDashboardService();
    }

    public function data(): void
    {
        Response::success($this->service->data());
    }
}
