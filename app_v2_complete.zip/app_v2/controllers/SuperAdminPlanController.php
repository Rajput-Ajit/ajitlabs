<?php

class SuperAdminPlanController
{
    private $service;

    public function __construct()
    {
        App::use('superAdminPlanService');
        $this->service = new SuperAdminPlanService();
    }

    public function list(): void
    {
        Response::success($this->service->list());
    }

    public function create(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        Response::success($this->service->create($data, $superAdmin));
    }

    public function update(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        $planId     = (int)($data['plan_id'] ?? 0);
        if (!$planId) Response::error('plan_id is required', 400);
        Response::success($this->service->update($planId, $data, $superAdmin));
    }
}
