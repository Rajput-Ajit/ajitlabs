<?php

class SuperAdminSubController
{
    private $service;

    public function __construct()
    {
        App::use('superAdminSubService');
        $this->service = new SuperAdminSubService();
    }

    // Create a new sub super admin
    public function create(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        Response::success($this->service->create($data, $superAdmin));
    }

    // List sub super admins created by this super admin
    public function list(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        Response::success($this->service->list($data, $superAdmin));
    }

    // Update permissions assigned to a sub super admin
    public function updatePermissions(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        Response::success($this->service->updatePermissions($data, $superAdmin));
    }

    // Block or unblock a sub super admin
    public function block(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        $subAdminId = (int)($data['sub_admin_id'] ?? 0);
        $status     = $data['status'] ?? 'blocked';

        if (!$subAdminId) Response::error('sub_admin_id is required', 400);

        $allowed = ['active', 'blocked', 'suspended'];
        if (!in_array($status, $allowed)) {
            Response::error('status must be: active, blocked, or suspended', 422);
        }

        Response::success($this->service->block($subAdminId, $status, $superAdmin));
    }
}
