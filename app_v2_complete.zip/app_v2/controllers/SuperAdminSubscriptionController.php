<?php

class SuperAdminSubscriptionController
{
    private $service;

    public function __construct()
    {
        App::use('superAdminSubscriptionService');
        $this->service = new SuperAdminSubscriptionService();
    }

    // List all subscriptions with optional filters
    public function list(array $data): void
    {
        Response::success($this->service->list($data));
    }

    // Approve a pending subscription (manually activate plan)
    public function approve(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        Response::success($this->service->approve($data, $superAdmin));
    }

    // Reject a pending subscription
    public function reject(array $data): void
    {
        $superAdmin = $_REQUEST['super_admin'];
        Response::success($this->service->reject($data, $superAdmin));
    }
}
