<?php

// ============================================================
// SuperAuthMiddleware.php
// ============================================================
// Same pattern as AuthMiddleware but checks super_admins table.
// Also attaches is_root (created_by IS NULL) and permissions
// array to $_REQUEST['super_admin'] so services can do
// permission checks without another DB query.
// ============================================================

class SuperAuthMiddleware
{
    public function handle()
    {
        App::useMany(['token', 'db', 'superAdminModel']);

        // 1. Verify JWT
        $token = Token::fromHeader();
        $user  = Token::verify($token); // exits 401 if bad

        $userId = $user->user_id ?? null;
        $type   = $user->type   ?? null;

        if (!$userId || $type !== 'super_admin') {
            Response::error('Access denied — super admin only', 403);
        }

        // 2. Live DB check against super_admins table
        $conn = DB::connect();
        $stmt = $conn->prepare("
            SELECT id, name, email, status, created_by, deleted_at
            FROM super_admins
            WHERE id = ?
            LIMIT 1
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $sa = $stmt->get_result()->fetch_assoc();

        if (!$sa || $sa['deleted_at'] !== null) {
            Response::error('Super admin account not found', 401);
        }

        if ($sa['status'] === 'blocked' || $sa['status'] === 'suspended') {
            Response::error("Account is {$sa['status']}", 403);
        }

        // 3. Attach to request
        $model = new SuperAdminModel();

        $_REQUEST['super_admin'] = [
            'user_id'     => $sa['id'],
            'name'        => $sa['name'],
            'email'       => $sa['email'],
            'type'        => 'super_admin',
            'is_root'     => ($sa['created_by'] === null), // root = all permissions
            'permissions' => $model->getPermissions($sa['id']),
        ];
    }
}
