<?php

// ============================================================
// SuperAdminAdminModel.php
// ============================================================
// Handles: cross-tenant queries on admins + their data
// Super admin needs to see ALL admins on the platform,
// their plans, branch/hall/student counts, revenue, status.
// ============================================================

class SuperAdminAdminModel
{
    private $conn;

    public function __construct()
    {
        $this->conn = DB::connect();
    }

    // =========================================================
    // LIST ALL ADMINS (paginated, filterable)
    // Returns rich summary row per admin including:
    //   plan info, counts, subscription status
    // MariaDB 10.4: uses subqueries (not JSON_ARRAYAGG)
    // =========================================================
    public function getAll(array $filters, int $limit, int $offset): array
    {
        $where  = ["a.deleted_at IS NULL"];
        $params = [];
        $types  = "";

        if (!empty($filters['status'])) {
            $where[]  = "a.status = ?";
            $params[] = $filters['status'];
            $types   .= "s";
        }

        if (!empty($filters['plan_id'])) {
            $where[]  = "a.plan_id = ?";
            $params[] = (int)$filters['plan_id'];
            $types   .= "i";
        }

        if (!empty($filters['search'])) {
            $where[]  = "(a.first_name LIKE ? OR a.last_name LIKE ? OR a.email LIKE ? OR a.contact LIKE ?)";
            $s        = "%" . $filters['search'] . "%";
            $params[] = $s; $params[] = $s; $params[] = $s; $params[] = $s;
            $types   .= "ssss";
        }

        if (!empty($filters['is_read_only'])) {
            $where[]  = "a.is_read_only = ?";
            $params[] = (int)$filters['is_read_only'];
            $types   .= "i";
        }

        $whereSql = implode(" AND ", $where);

        $sql = "
            SELECT
                a.id,
                a.uuid,
                a.first_name,
                a.last_name,
                a.email,
                a.contact,
                a.status,
                a.is_read_only,
                a.email_verified,
                a.contact_verified,
                a.plan_id,
                a.plan_expires_at,
                a.created_at,

                sp.name  AS plan_name,
                sp.slug  AS plan_slug,
                sp.price_monthly,

                -- Counts (subqueries — MariaDB 10.4 safe)
                (SELECT COUNT(*) FROM branches   WHERE admin_id = a.id AND deleted_at IS NULL) AS branch_count,
                (SELECT COUNT(*) FROM halls h2
                    JOIN branches b2 ON b2.id = h2.branch_id
                    WHERE b2.admin_id = a.id AND h2.deleted_at IS NULL)                        AS hall_count,
                (SELECT COUNT(*) FROM students   WHERE admin_id = a.id AND deleted_at IS NULL) AS student_count,
                (SELECT COALESCE(SUM(f.final_amount),0)
                    FROM fees f JOIN students st ON st.id = f.student_id
                    WHERE st.admin_id = a.id AND f.status = 'paid')                            AS total_revenue,

                -- Pending subscription (if any)
                (SELECT COUNT(*) FROM admin_subscriptions
                    WHERE admin_id = a.id AND status = 'pending')                              AS pending_payments

            FROM admins a
            LEFT JOIN subscription_plans sp ON sp.id = a.plan_id
            WHERE $whereSql
            ORDER BY a.created_at DESC
            LIMIT ? OFFSET ?
        ";

        $params[] = $limit;
        $params[] = $offset;
        $types   .= "ii";

        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // =========================================================
    // COUNT (pagination)
    // =========================================================
    public function countAll(array $filters): int
    {
        $where  = ["deleted_at IS NULL"];
        $params = [];
        $types  = "";

        if (!empty($filters['status'])) {
            $where[]  = "status = ?";
            $params[] = $filters['status'];
            $types   .= "s";
        }
        if (!empty($filters['plan_id'])) {
            $where[]  = "plan_id = ?";
            $params[] = (int)$filters['plan_id'];
            $types   .= "i";
        }
        if (!empty($filters['search'])) {
            $where[]  = "(first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)";
            $s        = "%" . $filters['search'] . "%";
            $params[] = $s; $params[] = $s; $params[] = $s;
            $types   .= "sss";
        }

        $whereSql = implode(" AND ", $where);
        $sql      = "SELECT COUNT(*) as cnt FROM admins WHERE $whereSql";

        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        return (int)($stmt->get_result()->fetch_assoc()['cnt'] ?? 0);
    }

    // =========================================================
    // VIEW SINGLE ADMIN (full detail)
    // Includes: profile, plan, branches, halls, recent students
    // =========================================================
    public function getDetail(int $adminId): ?array
    {
        // Core admin row
        $stmt = $this->conn->prepare("
            SELECT
                a.*,
                sp.name as plan_name, sp.slug as plan_slug,
                sp.max_branches, sp.max_halls, sp.max_students,
                sp.price_monthly
            FROM admins a
            LEFT JOIN subscription_plans sp ON sp.id = a.plan_id
            WHERE a.id = ? AND a.deleted_at IS NULL
            LIMIT 1
        ");
        $stmt->bind_param("i", $adminId);
        $stmt->execute();
        $admin = $stmt->get_result()->fetch_assoc();
        if (!$admin) return null;

        // Remove password hash from response
        unset($admin['password_hash']);

        // Branches
        $stmt2 = $this->conn->prepare("
            SELECT id, name, city, status, created_at
            FROM branches
            WHERE admin_id = ? AND deleted_at IS NULL
            ORDER BY created_at ASC
        ");
        $stmt2->bind_param("i", $adminId);
        $stmt2->execute();
        $admin['branches'] = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);

        // Recent 5 students
        $stmt3 = $this->conn->prepare("
            SELECT id, first_name, last_name, contact, status, created_at
            FROM students
            WHERE admin_id = ? AND deleted_at IS NULL
            ORDER BY created_at DESC
            LIMIT 5
        ");
        $stmt3->bind_param("i", $adminId);
        $stmt3->execute();
        $admin['recent_students'] = $stmt3->get_result()->fetch_all(MYSQLI_ASSOC);

        // Subscription history
        $stmt4 = $this->conn->prepare("
            SELECT asub.id, asub.plan_id, sp.name as plan_name,
                   asub.amount_paid, asub.payment_method, asub.status,
                   asub.start_date, asub.end_date, asub.created_at
            FROM admin_subscriptions asub
            JOIN subscription_plans sp ON sp.id = asub.plan_id
            WHERE asub.admin_id = ?
            ORDER BY asub.created_at DESC
            LIMIT 10
        ");
        $stmt4->bind_param("i", $adminId);
        $stmt4->execute();
        $admin['subscription_history'] = $stmt4->get_result()->fetch_all(MYSQLI_ASSOC);

        return $admin;
    }

    // =========================================================
    // BLOCK / UNBLOCK / SUSPEND ADMIN
    // =========================================================
    public function setStatus(int $adminId, string $status): bool
    {
        $allowed = ['active', 'blocked', 'suspended'];
        if (!in_array($status, $allowed)) return false;

        $stmt = $this->conn->prepare("
            UPDATE admins
            SET status = ?, updated_at = NOW()
            WHERE id = ? AND deleted_at IS NULL
        ");
        $stmt->bind_param("si", $status, $adminId);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }

    // =========================================================
    // SOFT DELETE ADMIN
    // Cascades: admins → branches → halls → seats/students
    // But we only soft-delete admins here — DB FK handles the rest
    // =========================================================
    public function softDelete(int $adminId): bool
    {
        $stmt = $this->conn->prepare("
            UPDATE admins
            SET deleted_at = NOW(), status = 'blocked', updated_at = NOW()
            WHERE id = ? AND deleted_at IS NULL
        ");
        $stmt->bind_param("i", $adminId);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }

    // =========================================================
    // PLATFORM KPI STATS (for super admin dashboard)
    // =========================================================
    public function getPlatformStats(): array
    {
        $result = $this->conn->query("
            SELECT
                (SELECT COUNT(*) FROM admins          WHERE deleted_at IS NULL)              AS total_admins,
                (SELECT COUNT(*) FROM admins          WHERE status='active' AND deleted_at IS NULL) AS active_admins,
                (SELECT COUNT(*) FROM admins          WHERE is_read_only=1  AND deleted_at IS NULL) AS expired_admins,
                (SELECT COUNT(*) FROM students        WHERE deleted_at IS NULL)              AS total_students,
                (SELECT COUNT(*) FROM halls           WHERE deleted_at IS NULL)              AS total_halls,
                (SELECT COUNT(*) FROM branches        WHERE deleted_at IS NULL)              AS total_branches,
                (SELECT COUNT(*) FROM admin_subscriptions WHERE status='pending')            AS pending_approvals,
                (SELECT COALESCE(SUM(amount_paid),0) FROM admin_subscriptions WHERE status='active') AS platform_revenue,
                (SELECT COUNT(*) FROM admins WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) AND deleted_at IS NULL) AS new_admins_30d
        ");
        return $result->fetch_assoc() ?: [];
    }

    // =========================================================
    // ADMIN GROWTH CHART (last 6 months)
    // New admins registered per month
    // =========================================================
    public function getAdminGrowth(): array
    {
        $result = $this->conn->query("
            SELECT
                DATE_FORMAT(created_at, '%b %Y') as month,
                COUNT(*) as count
            FROM admins
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
            AND deleted_at IS NULL
            GROUP BY YEAR(created_at), MONTH(created_at)
            ORDER BY created_at ASC
        ");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // =========================================================
    // PLAN DISTRIBUTION (how many admins on each plan)
    // =========================================================
    public function getPlanDistribution(): array
    {
        $result = $this->conn->query("
            SELECT
                sp.name as plan_name,
                sp.slug,
                COUNT(a.id) as admin_count
            FROM subscription_plans sp
            LEFT JOIN admins a ON a.plan_id = sp.id AND a.deleted_at IS NULL
            GROUP BY sp.id
            ORDER BY sp.display_order ASC
        ");
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
