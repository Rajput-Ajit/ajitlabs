<?php

// ============================================================
// SuperAdminModel.php
// ============================================================
// Handles: super_admins table, super_admin_permission_map,
//          super_admin_permissions catalogue
//
// Super admin is the PLATFORM owner / website owner.
// They sit ABOVE all reading-hall admins.
// Multiple super admins are allowed — first one is root,
// others are "sub super admins" created by root with
// specific permission codes.
//
// Tables used:
//   super_admins               — the super admin accounts
//   super_admin_permissions    — permission catalogue (codes)
//   super_admin_permission_map — which permissions a super admin has
// ============================================================

class SuperAdminModel
{
    private $conn;

    public function __construct()
    {
        $this->conn = DB::connect();
    }

    // =========================================================
    // FIND BY EMAIL
    // =========================================================
    public function findByEmail(string $email): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT * FROM super_admins
            WHERE email = ? AND deleted_at IS NULL
            LIMIT 1
        ");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    // =========================================================
    // FIND BY ID
    // =========================================================
    public function findById(int $id): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT id, name, email, status, created_by, created_at
            FROM super_admins
            WHERE id = ? AND deleted_at IS NULL
            LIMIT 1
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    // =========================================================
    // CREATE SUPER ADMIN (root — no created_by)
    // =========================================================
    public function createRoot(string $name, string $email, string $passwordHash): int
    {
        $stmt = $this->conn->prepare("
            INSERT INTO super_admins (name, email, password_hash, status)
            VALUES (?, ?, ?, 'active')
        ");
        $stmt->bind_param("sss", $name, $email, $passwordHash);
        $stmt->execute();
        return $this->conn->insert_id;
    }

    // =========================================================
    // CREATE SUB SUPER ADMIN (created by another super admin)
    // =========================================================
    public function createSub(string $name, string $email, string $passwordHash, int $createdBy): int
    {
        $stmt = $this->conn->prepare("
            INSERT INTO super_admins (name, email, password_hash, status, created_by)
            VALUES (?, ?, ?, 'active', ?)
        ");
        $stmt->bind_param("sssi", $name, $email, $passwordHash, $createdBy);
        $stmt->execute();
        return $this->conn->insert_id;
    }

    // =========================================================
    // COUNT ALL SUPER ADMINS (to detect first-time setup)
    // =========================================================
    public function count(): int
    {
        $result = $this->conn->query("
            SELECT COUNT(*) as cnt FROM super_admins WHERE deleted_at IS NULL
        ");
        return (int)($result->fetch_assoc()['cnt'] ?? 0);
    }

    // =========================================================
    // LIST ALL SUB SUPER ADMINS (created by a specific super admin)
    // =========================================================
    public function listSubs(int $createdBy, int $limit = 50, int $offset = 0): array
    {
        $stmt = $this->conn->prepare("
            SELECT
                sa.id,
                sa.name,
                sa.email,
                sa.status,
                sa.created_at,
                GROUP_CONCAT(sap.code ORDER BY sap.code SEPARATOR ',') as permissions
            FROM super_admins sa
            LEFT JOIN super_admin_permission_map sapm ON sapm.super_admin_id = sa.id
            LEFT JOIN super_admin_permissions sap    ON sap.id = sapm.permission_id
            WHERE sa.created_by = ? AND sa.deleted_at IS NULL
            GROUP BY sa.id
            ORDER BY sa.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->bind_param("iii", $createdBy, $limit, $offset);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // =========================================================
    // BLOCK / UNBLOCK SUB SUPER ADMIN
    // =========================================================
    public function setStatus(int $id, string $status): bool
    {
        $allowed = ['active', 'blocked', 'suspended'];
        if (!in_array($status, $allowed)) return false;

        $stmt = $this->conn->prepare("
            UPDATE super_admins SET status = ?, updated_at = NOW()
            WHERE id = ? AND deleted_at IS NULL
        ");
        $stmt->bind_param("si", $status, $id);
        $stmt->execute();
        return $stmt->affected_rows > 0;
    }

    // =========================================================
    // PERMISSION CATALOGUE — list all available permission codes
    // =========================================================
    public function getAllPermissions(): array
    {
        $result = $this->conn->query("
            SELECT id, code, description FROM super_admin_permissions
            ORDER BY code ASC
        ");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // =========================================================
    // ASSIGN PERMISSIONS TO SUB SUPER ADMIN
    // Replaces all existing permissions (full sync)
    // =========================================================
    public function syncPermissions(int $superAdminId, array $permissionIds, int $grantedBy): void
    {
        // Remove all existing
        $stmt = $this->conn->prepare("
            DELETE FROM super_admin_permission_map WHERE super_admin_id = ?
        ");
        $stmt->bind_param("i", $superAdminId);
        $stmt->execute();

        if (empty($permissionIds)) return;

        // Insert new
        $stmt = $this->conn->prepare("
            INSERT INTO super_admin_permission_map (super_admin_id, permission_id, granted_by)
            VALUES (?, ?, ?)
        ");
        foreach ($permissionIds as $permId) {
            $permId = (int)$permId;
            $stmt->bind_param("iii", $superAdminId, $permId, $grantedBy);
            $stmt->execute();
        }
    }

    // =========================================================
    // GET PERMISSIONS OF A SUPER ADMIN
    // Returns array of permission codes
    // =========================================================
    public function getPermissions(int $superAdminId): array
    {
        $stmt = $this->conn->prepare("
            SELECT sap.code
            FROM super_admin_permission_map sapm
            JOIN super_admin_permissions sap ON sap.id = sapm.permission_id
            WHERE sapm.super_admin_id = ?
        ");
        $stmt->bind_param("i", $superAdminId);
        $stmt->execute();
        $rows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        return array_column($rows, 'code');
    }

    // =========================================================
    // HAS PERMISSION (check single code)
    // =========================================================
    public function hasPermission(int $superAdminId, string $permCode): bool
    {
        // Root super admins (created_by = NULL) have ALL permissions
        $root = $this->conn->prepare("
            SELECT created_by FROM super_admins WHERE id = ? LIMIT 1
        ");
        $root->bind_param("i", $superAdminId);
        $root->execute();
        $row = $root->get_result()->fetch_assoc();
        if ($row && $row['created_by'] === null) return true;

        $stmt = $this->conn->prepare("
            SELECT 1 FROM super_admin_permission_map sapm
            JOIN super_admin_permissions sap ON sap.id = sapm.permission_id
            WHERE sapm.super_admin_id = ? AND sap.code = ?
            LIMIT 1
        ");
        $stmt->bind_param("is", $superAdminId, $permCode);
        $stmt->execute();
        return $stmt->get_result()->num_rows > 0;
    }
}
