<?php

// ============================================================
// SuperAdminPlanModel.php
// ============================================================
// Handles: subscription_plans table
// Super admin creates/edits plans.
// Admins subscribe to plans.
// Plan limits (max_branches, max_halls etc.) are enforced
// in admin-side services.
// ============================================================

class SuperAdminPlanModel
{
    private $conn;

    public function __construct()
    {
        $this->conn = DB::connect();
    }

    // =========================================================
    // LIST ALL PLANS
    // Includes subscriber count per plan for admin overview
    // =========================================================
    public function getAll(): array
    {
        // GROUP_CONCAT-free — use subquery for MariaDB 10.4 compat
        $result = $this->conn->query("
            SELECT
                sp.*,
                (
                    SELECT COUNT(*) FROM admin_subscriptions asub
                    WHERE asub.plan_id = sp.id AND asub.status = 'active'
                ) as active_subscribers
            FROM subscription_plans sp
            ORDER BY sp.display_order ASC, sp.id ASC
        ");
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // =========================================================
    // FIND BY ID
    // =========================================================
    public function findById(int $id): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT * FROM subscription_plans WHERE id = ? LIMIT 1
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    // =========================================================
    // FIND BY SLUG
    // =========================================================
    public function findBySlug(string $slug): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT * FROM subscription_plans WHERE slug = ? LIMIT 1
        ");
        $stmt->bind_param("s", $slug);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    // =========================================================
    // CREATE PLAN
    // =========================================================
    public function create(array $data): int
    {
        $stmt = $this->conn->prepare("
            INSERT INTO subscription_plans
            (name, slug, price_monthly, price_yearly,
             max_branches, max_halls, max_students, max_sub_admins,
             has_analytics, has_sms_alerts, has_fee_management,
             has_shift_timings, has_api_access, is_active, display_order)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "ssddiiiiiiiiiii",
            $data['name'],
            $data['slug'],
            $data['price_monthly'],
            $data['price_yearly'],
            $data['max_branches'],
            $data['max_halls'],
            $data['max_students'],
            $data['max_sub_admins'],
            $data['has_analytics'],
            $data['has_sms_alerts'],
            $data['has_fee_management'],
            $data['has_shift_timings'],
            $data['has_api_access'],
            $data['is_active'],
            $data['display_order']
        );

        $stmt->execute();
        return $this->conn->insert_id;
    }

    // =========================================================
    // UPDATE PLAN
    // Slug is NOT editable after creation (used as stable key)
    // =========================================================
    public function update(int $id, array $data): bool
    {
        $stmt = $this->conn->prepare("
            UPDATE subscription_plans SET
                name              = ?,
                price_monthly     = ?,
                price_yearly      = ?,
                max_branches      = ?,
                max_halls         = ?,
                max_students      = ?,
                max_sub_admins    = ?,
                has_analytics     = ?,
                has_sms_alerts    = ?,
                has_fee_management= ?,
                has_shift_timings = ?,
                has_api_access    = ?,
                is_active         = ?,
                display_order     = ?,
                updated_at        = NOW()
            WHERE id = ?
        ");

        $stmt->bind_param(
            "sddiiiiiiiiiiii",
            $data['name'],
            $data['price_monthly'],
            $data['price_yearly'],
            $data['max_branches'],
            $data['max_halls'],
            $data['max_students'],
            $data['max_sub_admins'],
            $data['has_analytics'],
            $data['has_sms_alerts'],
            $data['has_fee_management'],
            $data['has_shift_timings'],
            $data['has_api_access'],
            $data['is_active'],
            $data['display_order'],
            $id
        );

        $stmt->execute();
        return $stmt->affected_rows >= 0;
    }

    // =========================================================
    // TOGGLE PLAN ACTIVE STATUS
    // =========================================================
    public function toggleActive(int $id, int $isActive): void
    {
        $stmt = $this->conn->prepare("
            UPDATE subscription_plans SET is_active = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->bind_param("ii", $isActive, $id);
        $stmt->execute();
    }
}
