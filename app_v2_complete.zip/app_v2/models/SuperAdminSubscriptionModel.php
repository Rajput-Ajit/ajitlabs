<?php

// ============================================================
// SuperAdminSubscriptionModel.php
// ============================================================
// Handles: admin_subscriptions table
//
// Flow:
//   1. Admin registers → default free subscription inserted
//   2. Admin wants paid plan → they pay offline (cash/UPI)
//   3. Admin notifies super admin
//   4. Super admin sees pending subscription here
//   5. Super admin calls approve() → status = active,
//      admins.plan_id updated, admins.plan_expires_at updated
//      admins.is_read_only = 0
//
// This is the "manual payment approval" flow described in
// README_PROJECT.md — no payment gateway involved yet.
// ============================================================

class SuperAdminSubscriptionModel
{
    private $conn;

    public function __construct()
    {
        $this->conn = DB::connect();
    }

    // =========================================================
    // LIST ALL SUBSCRIPTIONS
    // Paginated, filterable by status / admin / plan
    // =========================================================
    public function getAll(array $filters, int $limit, int $offset): array
    {
        $where  = ["1=1"];
        $params = [];
        $types  = "";

        if (!empty($filters['status'])) {
            $where[]  = "asub.status = ?";
            $params[] = $filters['status'];
            $types   .= "s";
        }

        if (!empty($filters['admin_id'])) {
            $where[]  = "asub.admin_id = ?";
            $params[] = (int)$filters['admin_id'];
            $types   .= "i";
        }

        if (!empty($filters['plan_id'])) {
            $where[]  = "asub.plan_id = ?";
            $params[] = (int)$filters['plan_id'];
            $types   .= "i";
        }

        if (!empty($filters['search'])) {
            $where[]  = "(a.first_name LIKE ? OR a.last_name LIKE ? OR a.email LIKE ?)";
            $s        = "%" . $filters['search'] . "%";
            $params[] = $s; $params[] = $s; $params[] = $s;
            $types   .= "sss";
        }

        $whereSql = implode(" AND ", $where);

        $sql = "
            SELECT
                asub.id,
                asub.admin_id,
                asub.plan_id,
                asub.start_date,
                asub.end_date,
                asub.amount_paid,
                asub.payment_method,
                asub.payment_ref,
                asub.payment_note,
                asub.status,
                asub.approved_by,
                asub.created_at,
                CONCAT(a.first_name, ' ', COALESCE(a.last_name,'')) as admin_name,
                a.email  as admin_email,
                a.contact as admin_contact,
                sp.name  as plan_name,
                sp.slug  as plan_slug,
                sp.price_monthly,
                CONCAT(sa.name)  as approved_by_name
            FROM admin_subscriptions asub
            JOIN admins a            ON a.id  = asub.admin_id
            JOIN subscription_plans sp ON sp.id = asub.plan_id
            LEFT JOIN super_admins sa  ON sa.id = asub.approved_by
            WHERE $whereSql
            ORDER BY asub.created_at DESC
            LIMIT ? OFFSET ?
        ";

        $params[] = $limit;
        $params[] = $offset;
        $types   .= "ii";

        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    // =========================================================
    // COUNT (for pagination)
    // =========================================================
    public function countAll(array $filters): int
    {
        $where  = ["1=1"];
        $params = [];
        $types  = "";

        if (!empty($filters['status'])) {
            $where[]  = "asub.status = ?";
            $params[] = $filters['status'];
            $types   .= "s";
        }
        if (!empty($filters['admin_id'])) {
            $where[]  = "asub.admin_id = ?";
            $params[] = (int)$filters['admin_id'];
            $types   .= "i";
        }
        if (!empty($filters['plan_id'])) {
            $where[]  = "asub.plan_id = ?";
            $params[] = (int)$filters['plan_id'];
            $types   .= "i";
        }
        if (!empty($filters['search'])) {
            $where[]  = "(a.first_name LIKE ? OR a.email LIKE ?)";
            $s        = "%" . $filters['search'] . "%";
            $params[] = $s; $params[] = $s;
            $types   .= "ss";
        }

        $whereSql = implode(" AND ", $where);
        $sql = "
            SELECT COUNT(*) as cnt
            FROM admin_subscriptions asub
            JOIN admins a ON a.id = asub.admin_id
            WHERE $whereSql
        ";

        $stmt = $this->conn->prepare($sql);
        if (!empty($params)) $stmt->bind_param($types, ...$params);
        $stmt->execute();
        return (int)($stmt->get_result()->fetch_assoc()['cnt'] ?? 0);
    }

    // =========================================================
    // COUNT PENDING (for dashboard badge)
    // =========================================================
    public function countPending(): int
    {
        $result = $this->conn->query("
            SELECT COUNT(*) as cnt FROM admin_subscriptions WHERE status = 'pending'
        ");
        return (int)($result->fetch_assoc()['cnt'] ?? 0);
    }

    // =========================================================
    // FIND BY ID
    // =========================================================
    public function findById(int $id): ?array
    {
        $stmt = $this->conn->prepare("
            SELECT asub.*, sp.name as plan_name, sp.slug,
                   sp.max_branches, sp.max_halls, sp.max_students, sp.max_sub_admins,
                   CONCAT(a.first_name,' ',COALESCE(a.last_name,'')) as admin_name,
                   a.email as admin_email
            FROM admin_subscriptions asub
            JOIN subscription_plans sp ON sp.id = asub.plan_id
            JOIN admins a ON a.id = asub.admin_id
            WHERE asub.id = ?
            LIMIT 1
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc() ?: null;
    }

    // =========================================================
    // APPROVE SUBSCRIPTION
    // 1. Mark this subscription as active
    // 2. Expire ALL other active subscriptions for this admin
    // 3. Update admins.plan_id + plan_expires_at + is_read_only=0
    // All in a single transaction
    // =========================================================
    public function approve(int $subscriptionId, int $approvedBy): bool
    {
        $conn = $this->conn;

        // Fetch subscription first
        $sub = $this->findById($subscriptionId);
        if (!$sub) return false;

        $conn->begin_transaction();

        try {
            // Step 1: mark this subscription active
            $stmt1 = $conn->prepare("
                UPDATE admin_subscriptions
                SET status = 'active', approved_by = ?, updated_at = NOW()
                WHERE id = ?
            ");
            $stmt1->bind_param("ii", $approvedBy, $subscriptionId);
            $stmt1->execute();

            // Step 2: expire all OTHER active subscriptions for this admin
            $stmt2 = $conn->prepare("
                UPDATE admin_subscriptions
                SET status = 'expired', updated_at = NOW()
                WHERE admin_id = ? AND id != ? AND status = 'active'
            ");
            $stmt2->bind_param("ii", $sub['admin_id'], $subscriptionId);
            $stmt2->execute();

            // Step 3: update admins row
            $stmt3 = $conn->prepare("
                UPDATE admins
                SET plan_id         = ?,
                    plan_expires_at = ?,
                    is_read_only    = 0,
                    status          = 'active',
                    updated_at      = NOW()
                WHERE id = ?
            ");
            $stmt3->bind_param("isi", $sub['plan_id'], $sub['end_date'], $sub['admin_id']);
            $stmt3->execute();

            $conn->commit();
            return true;

        } catch (\Exception $e) {
            $conn->rollback();
            return false;
        }
    }

    // =========================================================
    // REJECT / CANCEL SUBSCRIPTION
    // =========================================================
    public function reject(int $subscriptionId, string $note = ''): void
    {
        $stmt = $this->conn->prepare("
            UPDATE admin_subscriptions
            SET status = 'cancelled', payment_note = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->bind_param("si", $note, $subscriptionId);
        $stmt->execute();
    }
}
