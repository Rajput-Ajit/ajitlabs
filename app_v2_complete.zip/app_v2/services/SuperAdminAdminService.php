<?php

// ============================================================
// SuperAdminAdminService.php
// ============================================================
// Manages reading-hall admin accounts from super admin perspective:
//   list, view detail, block/unblock/suspend, soft-delete
// ============================================================

class SuperAdminAdminService
{
    private $model;

    public function __construct()
    {
        App::use('superAdminAdminModel');
        $this->model = new SuperAdminAdminModel();
    }

    // =========================================================
    // LIST ALL ADMINS
    // =========================================================
    public function list(array $params): array
    {
        $limit  = (int)($params['limit']  ?? 15);
        $offset = (int)($params['offset'] ?? 0);

        $filters = [
            'status'       => $params['status']      ?? null,
            'plan_id'      => $params['plan_id']      ?? null,
            'search'       => $params['search']       ?? null,
            'is_read_only' => $params['is_read_only'] ?? null,
        ];

        $data  = $this->model->getAll($filters, $limit, $offset);
        $total = $this->model->countAll($filters);

        return [
            'total'  => $total,
            'limit'  => $limit,
            'offset' => $offset,
            'data'   => $data,
        ];
    }

    // =========================================================
    // VIEW SINGLE ADMIN DETAIL
    // =========================================================
    public function view(int $adminId): array
    {
        $detail = $this->model->getDetail($adminId);

        if (!$detail) {
            Response::error('Admin not found', 404);
        }

        return ['data' => $detail];
    }

    // =========================================================
    // BLOCK / UNBLOCK / SUSPEND
    // action: 'block' | 'unblock' | 'suspend'
    // =========================================================
    public function changeStatus(array $data, array $superAdmin): array
    {
        // Permission check — sub super admins need 'manage_admins'
        $this->_requirePermission($superAdmin, 'manage_admins');

        $adminId = (int)$data['admin_id'];
        $action  = $data['action'];

        $statusMap = [
            'block'   => 'blocked',
            'unblock' => 'active',
            'suspend' => 'suspended',
        ];

        $newStatus = $statusMap[$action] ?? null;
        if (!$newStatus) {
            Response::error('Invalid action. Use: block, unblock, suspend', 422);
        }

        // Prevent blocking yourself
        if ($adminId === ($superAdmin['user_id'] ?? 0)) {
            Response::error('You cannot change your own account status', 400);
        }

        $success = $this->model->setStatus($adminId, $newStatus);

        if (!$success) {
            Response::error('Admin not found or already in that status', 404);
        }

        return [
            'message'    => "Admin {$action}ed successfully",
            'admin_id'   => $adminId,
            'new_status' => $newStatus,
        ];
    }

    // =========================================================
    // SOFT DELETE
    // =========================================================
    public function delete(int $adminId, array $superAdmin): array
    {
        $this->_requirePermission($superAdmin, 'manage_admins');

        $success = $this->model->softDelete($adminId);

        if (!$success) {
            Response::error('Admin not found or already deleted', 404);
        }

        return ['message' => 'Admin account deleted successfully', 'admin_id' => $adminId];
    }

    // =========================================================
    // PERMISSION GUARD
    // Root super admins bypass this. Sub super admins need the code.
    // =========================================================
    private function _requirePermission(array $superAdmin, string $code): void
    {
        if ($superAdmin['is_root']) return; // root has all permissions

        if (!in_array($code, $superAdmin['permissions'] ?? [])) {
            Response::error("You don't have permission to: $code", 403);
        }
    }
}
