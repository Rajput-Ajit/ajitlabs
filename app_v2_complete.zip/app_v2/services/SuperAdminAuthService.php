<?php

// ============================================================
// SuperAdminAuthService.php
// ============================================================
// Handles: super admin login + first-time root registration.
//
// FIRST-TIME SETUP:
//   - If no super admin exists in DB, the register endpoint
//     allows creating the root super admin.
//   - A SETUP_KEY env variable protects this endpoint.
//     Set SETUP_KEY in .env before first deployment.
//   - After the root super admin is created, this endpoint
//     is disabled (returns 403).
//   - Root super admin can then create sub super admins
//     via superadmin.sub.create.php
//
// LOGIN:
//   - Checks super_admins table (not admins/users)
//   - Issues JWT with type = 'super_admin'
//   - SuperAuthMiddleware verifies this token
// ============================================================

class SuperAdminAuthService
{
    private $model;

    public function __construct()
    {
        App::useMany(['superAdminModel', 'token']);
        $this->model = new SuperAdminModel();
    }

    // =========================================================
    // LOGIN
    // =========================================================
    public function login(array $data): array
    {
        $sa = $this->model->findByEmail($data['email']);

        if (!$sa) {
            Response::error('Email not found', 404);
        }

        if (!password_verify($data['password'], $sa['password_hash'])) {
            Response::error('Invalid password', 401);
        }

        if ($sa['status'] === 'blocked' || $sa['status'] === 'suspended') {
            Response::error("Your account is {$sa['status']}", 403);
        }

        // Issue JWT with type = 'super_admin'
        $token = Token::create($sa['id'], 'super_admin', $sa['email']);

        $isRoot = ($sa['created_by'] === null);

        return [
            'message'     => 'Login successful',
            'token'       => $token,
            'super_admin' => [
                'id'      => $sa['id'],
                'name'    => $sa['name'],
                'email'   => $sa['email'],
                'is_root' => $isRoot,
            ]
        ];
    }

    // =========================================================
    // REGISTER ROOT (first-time setup only)
    // =========================================================
    public function register(array $data): array
    {
        // Only allowed if NO super admin exists yet
        if ($this->model->count() > 0) {
            Response::error(
                'Setup already complete. Root super admin already exists. ' .
                'Use the sub-admin creation API to add more super admins.',
                403
            );
        }

        // Verify setup key matches .env
        $envKey = $_ENV['SUPER_ADMIN_SETUP_KEY'] ?? 'change-me-in-env';
        if ($data['setup_key'] !== $envKey) {
            Response::error('Invalid setup key', 403);
        }

        if ($this->model->findByEmail($data['email'])) {
            Response::error('Email already registered', 409);
        }

        $passwordHash = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);

        $id = $this->model->createRoot($data['name'], $data['email'], $passwordHash);

        $token = Token::create($id, 'super_admin', $data['email']);

        return [
            'message' => 'Root super admin created successfully',
            'token'   => $token,
            'id'      => $id,
        ];
    }
}
