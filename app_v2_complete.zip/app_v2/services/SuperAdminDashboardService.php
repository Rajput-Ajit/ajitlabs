<?php

// ============================================================
// SuperAdminDashboardService.php
// ============================================================
// Returns platform-wide stats visible only to super admin.
// No admin_id scope — this intentionally sees ALL tenants.
// ============================================================

class SuperAdminDashboardService
{
    private $adminModel;
    private $subModel;

    public function __construct()
    {
        App::useMany(['superAdminAdminModel', 'superAdminSubscriptionModel']);
        $this->adminModel = new SuperAdminAdminModel();
        $this->subModel   = new SuperAdminSubscriptionModel();
    }

    public function data(): array
    {
        $stats       = $this->adminModel->getPlatformStats();
        $growth      = $this->adminModel->getAdminGrowth();
        $planDist    = $this->adminModel->getPlanDistribution();
        $pendingCount = $this->subModel->countPending();

        // Recent 5 pending subscriptions (need approval)
        $pendingSubs = $this->subModel->getAll(
            ['status' => 'pending'], 5, 0
        );

        return [
            'stats' => [
                'total_admins'      => (int)($stats['total_admins']      ?? 0),
                'active_admins'     => (int)($stats['active_admins']     ?? 0),
                'expired_admins'    => (int)($stats['expired_admins']    ?? 0),
                'total_students'    => (int)($stats['total_students']    ?? 0),
                'total_halls'       => (int)($stats['total_halls']       ?? 0),
                'total_branches'    => (int)($stats['total_branches']    ?? 0),
                'pending_approvals' => (int)($stats['pending_approvals'] ?? 0),
                'platform_revenue'  => (float)($stats['platform_revenue'] ?? 0),
                'new_admins_30d'    => (int)($stats['new_admins_30d']    ?? 0),
            ],
            'charts' => [
                'admin_growth'      => $growth,
                'plan_distribution' => $planDist,
            ],
            'pending_subscriptions' => $pendingSubs,
        ];
    }
}
