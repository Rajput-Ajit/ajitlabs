<?php

// ============================================================
// SuperAdminPlanService.php
// ============================================================
// Manages subscription plans (Free / Starter / Pro / Enterprise).
// Only root super admin or sub super admin with 'manage_plans'
// permission can create/edit plans.
// ============================================================

class SuperAdminPlanService
{
    private $model;

    public function __construct()
    {
        App::use('superAdminPlanModel');
        $this->model = new SuperAdminPlanModel();
    }

    // =========================================================
    // LIST ALL PLANS
    // =========================================================
    public function list(): array
    {
        $plans = $this->model->getAll();

        // Cast all numeric fields
        foreach ($plans as &$plan) {
            $plan['id']                 = (int)$plan['id'];
            $plan['price_monthly']      = (float)$plan['price_monthly'];
            $plan['price_yearly']       = $plan['price_yearly'] ? (float)$plan['price_yearly'] : null;
            $plan['max_branches']       = (int)$plan['max_branches'];
            $plan['max_halls']          = (int)$plan['max_halls'];
            $plan['max_students']       = (int)$plan['max_students'];
            $plan['max_sub_admins']     = (int)$plan['max_sub_admins'];
            $plan['has_analytics']      = (bool)$plan['has_analytics'];
            $plan['has_sms_alerts']     = (bool)$plan['has_sms_alerts'];
            $plan['has_fee_management'] = (bool)$plan['has_fee_management'];
            $plan['has_shift_timings']  = (bool)$plan['has_shift_timings'];
            $plan['has_api_access']     = (bool)$plan['has_api_access'];
            $plan['is_active']          = (bool)$plan['is_active'];
            $plan['active_subscribers'] = (int)$plan['active_subscribers'];
        }

        return ['data' => $plans];
    }

    // =========================================================
    // CREATE PLAN
    // =========================================================
    public function create(array $data, array $superAdmin): array
    {
        $this->_requirePermission($superAdmin, 'manage_plans');

        // Generate slug from name if not provided
        if (empty($data['slug'])) {
            $data['slug'] = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $data['name']));
            $data['slug'] = trim($data['slug'], '-');
        }

        // Check slug uniqueness
        if ($this->model->findBySlug($data['slug'])) {
            Response::error("A plan with slug '{$data['slug']}' already exists", 409);
        }

        $planData = [
            'name'              => $data['name'],
            'slug'              => $data['slug'],
            'price_monthly'     => (float)($data['price_monthly']   ?? 0),
            'price_yearly'      => isset($data['price_yearly']) ? (float)$data['price_yearly'] : null,
            'max_branches'      => (int)($data['max_branches']      ?? 1),
            'max_halls'         => (int)($data['max_halls']          ?? 1),
            'max_students'      => (int)($data['max_students']       ?? 50),
            'max_sub_admins'    => (int)($data['max_sub_admins']     ?? 0),
            'has_analytics'     => (int)(!empty($data['has_analytics'])),
            'has_sms_alerts'    => (int)(!empty($data['has_sms_alerts'])),
            'has_fee_management'=> (int)(!empty($data['has_fee_management'])),
            'has_shift_timings' => (int)(!empty($data['has_shift_timings'])),
            'has_api_access'    => (int)(!empty($data['has_api_access'])),
            'is_active'         => (int)($data['is_active'] ?? 1),
            'display_order'     => (int)($data['display_order'] ?? 99),
        ];

        $id = $this->model->create($planData);

        return [
            'message' => 'Plan created successfully',
            'plan_id' => $id,
            'slug'    => $planData['slug'],
        ];
    }

    // =========================================================
    // UPDATE PLAN
    // =========================================================
    public function update(int $planId, array $data, array $superAdmin): array
    {
        $this->_requirePermission($superAdmin, 'manage_plans');

        $existing = $this->model->findById($planId);
        if (!$existing) {
            Response::error('Plan not found', 404);
        }

        // Prevent editing the slug
        $planData = [
            'name'              => $data['name']              ?? $existing['name'],
            'price_monthly'     => (float)($data['price_monthly']   ?? $existing['price_monthly']),
            'price_yearly'      => isset($data['price_yearly']) ? (float)$data['price_yearly'] : $existing['price_yearly'],
            'max_branches'      => (int)($data['max_branches']      ?? $existing['max_branches']),
            'max_halls'         => (int)($data['max_halls']          ?? $existing['max_halls']),
            'max_students'      => (int)($data['max_students']       ?? $existing['max_students']),
            'max_sub_admins'    => (int)($data['max_sub_admins']     ?? $existing['max_sub_admins']),
            'has_analytics'     => isset($data['has_analytics'])     ? (int)$data['has_analytics']     : (int)$existing['has_analytics'],
            'has_sms_alerts'    => isset($data['has_sms_alerts'])    ? (int)$data['has_sms_alerts']    : (int)$existing['has_sms_alerts'],
            'has_fee_management'=> isset($data['has_fee_management'])? (int)$data['has_fee_management']: (int)$existing['has_fee_management'],
            'has_shift_timings' => isset($data['has_shift_timings']) ? (int)$data['has_shift_timings'] : (int)$existing['has_shift_timings'],
            'has_api_access'    => isset($data['has_api_access'])    ? (int)$data['has_api_access']    : (int)$existing['has_api_access'],
            'is_active'         => isset($data['is_active'])         ? (int)$data['is_active']         : (int)$existing['is_active'],
            'display_order'     => (int)($data['display_order']      ?? $existing['display_order']),
        ];

        $this->model->update($planId, $planData);

        return [
            'message' => 'Plan updated successfully',
            'plan_id' => $planId,
        ];
    }

    private function _requirePermission(array $superAdmin, string $code): void
    {
        if ($superAdmin['is_root']) return;
        if (!in_array($code, $superAdmin['permissions'] ?? [])) {
            Response::error("Permission denied: $code", 403);
        }
    }
}
