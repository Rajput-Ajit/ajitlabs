<?php

// ============================================================
// SuperAdminSubService.php
// ============================================================
// Root super admin can create sub super admins with limited
// permissions. Sub super admins can only do what their
// permission codes allow.
//
// Permissions catalogue (super_admin_permissions table):
//   manage_admins    — block/unblock/delete admins
//   manage_plans     — create/edit subscription plans
//   approve_payments — approve admin subscription payments
//   view_reports     — access platform-wide reports
//   manage_subs      — create/edit sub super admins
// ============================================================

class SuperAdminSubService
{
    private $model;

    public function __construct()
    {
        App::use('superAdminModel');
        $this->model = new SuperAdminModel();
    }

    // =========================================================
    // CREATE SUB SUPER ADMIN
    // Only root or super admin with 'manage_subs' can do this
    // =========================================================
    public function create(array $data, array $superAdmin): array
    {
        $this->_requirePermission($superAdmin, 'manage_subs');

        if ($this->model->findByEmail($data['email'])) {
            Response::error('Email already registered as a super admin', 409);
        }

        $passwordHash = password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]);

        $id = $this->model->createSub(
            $data['name'],
            $data['email'],
            $passwordHash,
            $superAdmin['user_id']
        );

        // Assign permissions if provided
        $permissionIds = $data['permission_ids'] ?? [];
        if (!empty($permissionIds)) {
            $this->model->syncPermissions($id, $permissionIds, $superAdmin['user_id']);
        }

        return [
            'message'         => 'Sub super admin created successfully',
            'sub_admin_id'    => $id,
            'permissions_set' => count($permissionIds),
        ];
    }

    // =========================================================
    // LIST SUB SUPER ADMINS (created by this super admin)
    // =========================================================
    public function list(array $params, array $superAdmin): array
    {
        $limit  = (int)($params['limit']  ?? 20);
        $offset = (int)($params['offset'] ?? 0);

        $subs = $this->model->listSubs($superAdmin['user_id'], $limit, $offset);

        // Parse comma-separated permissions string into array
        foreach ($subs as &$sub) {
            $sub['permissions'] = $sub['permissions']
                ? explode(',', $sub['permissions'])
                : [];
        }

        // Also return full permission catalogue for UI checkbox list
        $catalogue = $this->model->getAllPermissions();

        return [
            'data'      => $subs,
            'catalogue' => $catalogue,
        ];
    }

    // =========================================================
    // UPDATE SUB SUPER ADMIN PERMISSIONS
    // =========================================================
    public function updatePermissions(array $data, array $superAdmin): array
    {
        $this->_requirePermission($superAdmin, 'manage_subs');

        $subAdminId    = (int)$data['sub_admin_id'];
        $permissionIds = $data['permissions'] ?? [];

        // Verify the sub admin was created by this super admin
        $subs = $this->model->listSubs($superAdmin['user_id'], 200, 0);
        $ids  = array_column($subs, 'id');

        if (!in_array($subAdminId, $ids)) {
            Response::error('Sub admin not found or not under your account', 404);
        }

        $this->model->syncPermissions($subAdminId, $permissionIds, $superAdmin['user_id']);

        return [
            'message'         => 'Permissions updated successfully',
            'sub_admin_id'    => $subAdminId,
            'permissions_set' => count($permissionIds),
        ];
    }

    // =========================================================
    // BLOCK SUB SUPER ADMIN
    // =========================================================
    public function block(int $subAdminId, string $status, array $superAdmin): array
    {
        $this->_requirePermission($superAdmin, 'manage_subs');

        $success = $this->model->setStatus($subAdminId, $status);

        if (!$success) {
            Response::error('Sub admin not found', 404);
        }

        return [
            'message'      => "Sub admin $status successfully",
            'sub_admin_id' => $subAdminId,
            'status'       => $status,
        ];
    }

    // =========================================================
    // PERMISSION GUARD
    // =========================================================
    private function _requirePermission(array $superAdmin, string $code): void
    {
        if ($superAdmin['is_root']) return;
        if (!in_array($code, $superAdmin['permissions'] ?? [])) {
            Response::error("Permission denied: $code", 403);
        }
    }
}
