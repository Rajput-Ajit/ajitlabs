<?php

// ============================================================
// SuperAdminSubscriptionService.php
// ============================================================
// Handles manual payment approval flow.
// When an admin pays (cash/UPI), they notify the super admin.
// Super admin reviews and approves here → plan activates.
// ============================================================

class SuperAdminSubscriptionService
{
    private $model;

    public function __construct()
    {
        App::use('superAdminSubscriptionModel');
        $this->model = new SuperAdminSubscriptionModel();
    }

    // =========================================================
    // LIST SUBSCRIPTIONS (filterable by status/admin/plan)
    // =========================================================
    public function list(array $params): array
    {
        $limit  = (int)($params['limit']  ?? 15);
        $offset = (int)($params['offset'] ?? 0);

        $filters = [
            'status'   => $params['status']   ?? null,
            'admin_id' => $params['admin_id'] ?? null,
            'plan_id'  => $params['plan_id']  ?? null,
            'search'   => $params['search']   ?? null,
        ];

        $data  = $this->model->getAll($filters, $limit, $offset);
        $total = $this->model->countAll($filters);

        return [
            'total'  => $total,
            'limit'  => $limit,
            'offset' => $offset,
            'data'   => $data,
        ];
    }

    // =========================================================
    // APPROVE SUBSCRIPTION
    // =========================================================
    public function approve(array $data, array $superAdmin): array
    {
        $this->_requirePermission($superAdmin, 'approve_payments');

        $subscriptionId = (int)$data['subscription_id'];

        $sub = $this->model->findById($subscriptionId);
        if (!$sub) {
            Response::error('Subscription record not found', 404);
        }

        if ($sub['status'] === 'active') {
            Response::error('This subscription is already active', 400);
        }

        if ($sub['status'] === 'cancelled' || $sub['status'] === 'refunded') {
            Response::error("Cannot approve a {$sub['status']} subscription", 400);
        }

        $success = $this->model->approve($subscriptionId, $superAdmin['user_id']);

        if (!$success) {
            Response::error('Failed to approve subscription. Please try again.', 500);
        }

        return [
            'message'         => "Subscription approved. {$sub['admin_name']}'s plan is now active.",
            'subscription_id' => $subscriptionId,
            'admin_id'        => $sub['admin_id'],
            'plan_name'       => $sub['plan_name'],
            'valid_until'     => $sub['end_date'],
        ];
    }

    // =========================================================
    // REJECT SUBSCRIPTION
    // =========================================================
    public function reject(array $data, array $superAdmin): array
    {
        $this->_requirePermission($superAdmin, 'approve_payments');

        $subscriptionId = (int)$data['subscription_id'];
        $note           = $data['note'] ?? '';

        $sub = $this->model->findById($subscriptionId);
        if (!$sub) {
            Response::error('Subscription record not found', 404);
        }

        if ($sub['status'] !== 'pending') {
            Response::error("Only pending subscriptions can be rejected (current: {$sub['status']})", 400);
        }

        $this->model->reject($subscriptionId, $note);

        return [
            'message'         => 'Subscription rejected.',
            'subscription_id' => $subscriptionId,
        ];
    }

    private function _requirePermission(array $superAdmin, string $code): void
    {
        if ($superAdmin['is_root']) return;
        if (!in_array($code, $superAdmin['permissions'] ?? [])) {
            Response::error("Permission denied: $code", 403);
        }
    }
}
