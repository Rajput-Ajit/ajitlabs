<?php

// ============================================================
// SuperAdminValidator.php
// ============================================================
// Validation rules for all super admin API inputs.
// Same fluent Validator pattern used throughout the project.
// ============================================================

class SuperAdminValidator
{
    protected static $v = null;

    protected static function validator(): Validator
    {
        if (self::$v === null) self::$v = new Validator();
        return self::$v;
    }

    // =========================================================
    // LOGIN
    // =========================================================
    public static function validateLogin(array $data): void
    {
        $v = self::validator();
        $v->required('Email', $data['email'] ?? null)
          ->email('Email', $data['email'] ?? null)
          ->required('Password', $data['password'] ?? null)
          ->minLength('Password', $data['password'] ?? null, 6);
        if ($v->hasErrors()) Response::error($v->firstError(), 422);
    }

    // =========================================================
    // REGISTER (first super admin / root setup)
    // =========================================================
    public static function validateRegister(array $data): void
    {
        $v = self::validator();
        $v->required('Name', $data['name'] ?? null)
          ->minLength('Name', $data['name'] ?? null, 3)
          ->maxLength('Name', $data['name'] ?? null, 100)
          ->required('Email', $data['email'] ?? null)
          ->email('Email', $data['email'] ?? null)
          ->required('Password', $data['password'] ?? null)
          ->minLength('Password', $data['password'] ?? null, 8)
          ->required('Setup Key', $data['setup_key'] ?? null); // prevents random signups
        if ($v->hasErrors()) Response::error($v->firstError(), 422);
    }

    // =========================================================
    // CREATE / UPDATE PLAN
    // =========================================================
    public static function validatePlan(array $data): void
    {
        $v = self::validator();
        $v->required('Plan Name', $data['name'] ?? null)
          ->minLength('Plan Name', $data['name'] ?? null, 2)
          ->maxLength('Plan Name', $data['name'] ?? null, 100)
          ->required('Monthly Price', $data['price_monthly'] ?? null)
          ->greaterThan('Monthly Price', $data['price_monthly'] ?? null, -1) // 0 allowed (free)
          ->required('Max Branches', $data['max_branches'] ?? null)
          ->numeric('Max Branches', $data['max_branches'] ?? null)
          ->required('Max Halls', $data['max_halls'] ?? null)
          ->numeric('Max Halls', $data['max_halls'] ?? null)
          ->required('Max Students', $data['max_students'] ?? null)
          ->numeric('Max Students', $data['max_students'] ?? null);
        if ($v->hasErrors()) Response::error($v->firstError(), 422);
    }

    // =========================================================
    // APPROVE SUBSCRIPTION
    // =========================================================
    public static function validateApprove(array $data): void
    {
        $v = self::validator();
        $v->required('Subscription ID', $data['subscription_id'] ?? null)
          ->numeric('Subscription ID', $data['subscription_id'] ?? null)
          ->greaterThan('Subscription ID', $data['subscription_id'] ?? null, 0);
        if ($v->hasErrors()) Response::error($v->firstError(), 422);
    }

    // =========================================================
    // BLOCK / UNBLOCK ADMIN
    // =========================================================
    public static function validateAdminAction(array $data): void
    {
        $v = self::validator();
        $v->required('Admin ID', $data['admin_id'] ?? null)
          ->numeric('Admin ID', $data['admin_id'] ?? null)
          ->greaterThan('Admin ID', $data['admin_id'] ?? null, 0)
          ->required('Action', $data['action'] ?? null);

        $allowed = ['block', 'unblock', 'suspend'];
        if (!empty($data['action']) && !in_array($data['action'], $allowed)) {
            Response::error("Action must be one of: " . implode(', ', $allowed), 422);
        }
        if ($v->hasErrors()) Response::error($v->firstError(), 422);
    }

    // =========================================================
    // CREATE SUB SUPER ADMIN
    // =========================================================
    public static function validateSubCreate(array $data): void
    {
        $v = self::validator();
        $v->required('Name', $data['name'] ?? null)
          ->minLength('Name', $data['name'] ?? null, 3)
          ->required('Email', $data['email'] ?? null)
          ->email('Email', $data['email'] ?? null)
          ->required('Password', $data['password'] ?? null)
          ->minLength('Password', $data['password'] ?? null, 8);
        if ($v->hasErrors()) Response::error($v->firstError(), 422);
    }

    // =========================================================
    // UPDATE SUB SUPER ADMIN PERMISSIONS
    // =========================================================
    public static function validateSubUpdate(array $data): void
    {
        $v = self::validator();
        $v->required('Sub Admin ID', $data['sub_admin_id'] ?? null)
          ->numeric('Sub Admin ID', $data['sub_admin_id'] ?? null)
          ->greaterThan('Sub Admin ID', $data['sub_admin_id'] ?? null, 0);

        if (!isset($data['permissions']) || !is_array($data['permissions'])) {
            Response::error('Permissions must be an array of permission IDs', 422);
        }
        if ($v->hasErrors()) Response::error($v->firstError(), 422);
    }
}
