/**
 * auth/admin/login.js — Admin Login Page
 * ────────────────────────────────────────
 * Depends on: core/api.js, core/helpers.js, core/ui.js
 *
 * Expected HTML elements:
 *   <form id="login-form">
 *     <input name="email"    type="email">
 *     <input name="password" type="password">
 *     <button type="submit" id="login-btn">Login</button>
 *   </form>
 */

document.addEventListener('DOMContentLoaded', () => {

  // Redirect away if already logged in
  Guard.redirectIfLoggedIn('admin');

  const form    = Dom.el('#login-form');
  const btn     = Dom.el('#login-btn');

  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    Form.clearErrors(form);

    const body = Form.serialize(form);

    // Basic client-side check before hitting server
    if (!body.email || !body.password) {
      UI.toast.warning('Please fill in all fields.');
      return;
    }

    Form.disable(btn, 'Logging in...');

    try {
      const res = await Api.post('/app/api/admin.login.php', body);

      // Save JWT token to cookie
      Api.saveToken(res.token);

      UI.toast.success(res.message || 'Login successful!');

      // Redirect after short delay so user sees the toast
      setTimeout(() => {
        window.location.href = '/public/admin/dashboard.php';
      }, 800);

    } catch (err) {
      // Api.post() already showed the error toast
      Form.enable(btn);
    }
  });

});
